# DBT Portal — Prototype

1. Copy the files into a directory `dbt-portal`.
2. Serve with any static server (VS Code Live Server, Python `http.server`, or similar):
   - `python -m http.server 8000` then open http://localhost:8000/index.html
3. Use the pages: Register beneficiaries, simulate sanctions and disbursements, file grievances (via API), and export data.

Notes: This is a frontend prototype using localStorage as a mock backend. For production, replace `js/mock-api.js` with secure server endpoints, integrate Aadhaar/DigiLocker via government APIs, and add proper encryption/authentication.
