/* Simple mock API using localStorage to simulate DBT flows.
   This file exposes window.API with functions to manage beneficiaries, sanctions, disbursements and grievances.
*/
(function(){
  const KEY = 'dbt_portal_data_v1';
  const defaultData = {
    beneficiaries: [],
    sanctions: [],
    disbursements: [],
    grievances: [],
    audit: []
  };

  function load(){
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(defaultData));
  }
  function save(data){ localStorage.setItem(KEY, JSON.stringify(data)); }
  function logEvent(type, meta){
    const data = load();
    data.audit.unshift({ time: new Date().toISOString(), type, meta });
    save(data);
  }

  window.API = {
    reset(){ localStorage.removeItem(KEY); save(defaultData); },
    getAll(){ return load(); },
    addBeneficiary(b){
      const data = load();
      b.id = 'B' + Math.random().toString(36).slice(2,9);
      b.status = 'registered';
      b.createdAt = new Date().toISOString();
      data.beneficiaries.push(b);
      logEvent('beneficiary_registered',{id:b.id,name:b.name});
      save(data);
      return b;
    },
    listBeneficiaries(){ return load().beneficiaries.slice().reverse(); },
    mockImportDigi(){
      // returns a mocked record
      return { name: 'A. Kumar', mobile:'9998877665', aadhaar: 'XXXX-XXXX-1234', district:'Sample', pincode:'400001' }
    },
    sanction(beneficiaryId, amount){
      const data = load();
      const s = { id:'S'+Date.now(), beneficiaryId, amount, status:'sanctioned', time:new Date().toISOString() };
      data.sanctions.push(s);
      logEvent('sanction_created', s);
      save(data);
      return s;
    },
    disburse(sanctionId, txRef){
      const data = load();
      const sanction = data.sanctions.find(x=>x.id===sanctionId);
      if(!sanction) throw new Error('Sanction not found');
      sanction.status='disbursed';
      const d = { id:'D'+Date.now(), sanctionId, txRef: txRef||('TX'+Math.random().toString(36).slice(2,8)), time: new Date().toISOString() };
      data.disbursements.push(d);
      logEvent('disbursed', d);
      save(data);
      return d;
    },
    fileGrievance(g){ const data = load(); g.id='G'+Date.now(); g.time=new Date().toISOString(); data.grievances.push(g); logEvent('grievance_filed',g); save(data); return g; },
    listAudit(){ return load().audit.slice(); },
    exportCSV(){ const d = load(); return d },
    simulateAadhaarMatch(aadhaar){ // mock fuzzy match
      const data = load(); return data.beneficiaries.find(b=>b.aadhaar && b.aadhaar.endsWith(aadhaar.slice(-4))); }
  };

  // ensure data exists
  if(!localStorage.getItem(KEY)) save(defaultData);
})();
