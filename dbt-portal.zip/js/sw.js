// Very small service worker to cache shell for offline use (demo only)
const CACHE = 'dbt-portal-cache-v1';
const FILES = ['/', '/index.html', '/dashboard.html', '/beneficiary.html', '/admin.html', '/css/styles.css', '/js/app.js', '/js/mock-api.js'];
self.addEventListener('install', evt=>{
  evt.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)));
});
self.addEventListener('fetch', evt=>{
  evt.respondWith(caches.match(evt.request).then(r=>r||fetch(evt.request)));
});
