/* Front-end glue code. Handles UI interactions across pages and ties into window.API mock.
   Designed to be simple and readable; replace mock with real API endpoints as needed.
*/
(function(){
  // Shared helpers
  function qs(sel,root=document){return root.querySelector(sel)}
  function qsa(sel,root=document){return Array.from(root.querySelectorAll(sel))}

  /* Theme toggle (simple) */
  const themeToggle = qs('#themeToggle');
  if(themeToggle) themeToggle.addEventListener('click', ()=> document.documentElement.classList.toggle('dark'));

  // Index quick action handlers
  window.openRegister = ()=> location.href='beneficiary.html';
  window.openTrack = ()=> location.href='dashboard.html';
  window.openGrievance = ()=> alert('Use Beneficiary page to file grievance or open Admin > Grievance');

  // Beneficiary page
  const bf = qs('#beneficiaryForm');
  if(bf){
    const list = qs('#beneficiaryList');
    function renderBeneficiaries(){
      const items = window.API.listBeneficiaries();
      list.innerHTML = items.map(b=>{
        return `
          <div class="p-3 border-b">
            <div class="flex justify-between items-start">
              <div>
                <div class="font-semibold">${escapeHTML(b.name)}</div>
                <div class="text-xs text-gray-500">${b.district||''} • ${b.pincode||''} • ${b.mobile||''}</div>
                <div class="text-sm mt-2">${escapeHTML(b.notes||'')}</div>
              </div>
              <div class="text-right">
                <div class="text-xs text-gray-400">${new Date(b.createdAt).toLocaleString()}</div>
                <div class="mt-2">
                  <button onclick="window.API.sanction('${b.id}',5000)" class="px-2 py-1 border rounded text-xs">Sanction</button>
                </div>
              </div>
            </div>
          </div>
        `
      }).join('');
    }
    // escape helper
    function escapeHTML(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

    bf.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const form = new FormData(bf);
      const obj = Object.fromEntries(form.entries());
      const saved = window.API.addBeneficiary(obj);
      renderBeneficiaries();
      alert('Saved: '+saved.id);
      bf.reset();
    });

    const importBtn = qs('#importDigi');
    if(importBtn) importBtn.addEventListener('click', ()=>{
      const d = window.API.mockImportDigi();
      bf.name.value = d.name; bf.mobile.value = d.mobile; bf.aadhaar.value = d.aadhaar; bf.district.value = d.district; bf.pincode.value = d.pincode;
    });

    renderBeneficiaries();
  }

  // Dashboard page
  const statTotal = qs('#statTotal');
  const statPending = qs('#statPending');
  const statGriev = qs('#statGriev');
  if(statTotal){
    function renderStats(){
      const d = window.API.getAll();
      statTotal.textContent = d.beneficiaries.length;
      statPending.textContent = d.sanctions.filter(s=>s.status!=='disbursed').length;
      statGriev.textContent = d.grievances.length;

      const sel = qs('#selectBeneficiary');
      if(sel){
        sel.innerHTML = '<option value="">-- choose --</option>' + d.beneficiaries.map(b=>`<option value="${b.id}">${b.name} (${b.id})</option>`).join('');
      }

      const auditLog = qs('#auditLog');
      if(auditLog) auditLog.innerHTML = window.API.listAudit().map(a=>`<div class="p-2 border-b"><div class="text-xs text-gray-400">${new Date(a.time).toLocaleString()}</div><div>${escapeHTML(a.type)} — ${escapeHTML(JSON.stringify(a.meta))}</div></div>`).join('');
    }

    renderStats();

    // Map
    const mapEl = qs('#map');
    if(mapEl && typeof L !== 'undefined'){
      const map = L.map('map').setView([21.0,78.9], 4);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
      const d = window.API.getAll();
      d.beneficiaries.forEach(b=>{
        const lat = parseFloat(b.lat), lng = parseFloat(b.lng);
        if(!isNaN(lat) && !isNaN(lng)){
          L.marker([lat,lng]).addTo(map).bindPopup(`${b.name} — ${b.id}`);
        }
      });
    }

    // Sanction & disburse handlers
    const sanctionBtn = qs('#sanctionBtn');
    const disburseBtn = qs('#disburseBtn');
    sanctionBtn && sanctionBtn.addEventListener('click', ()=>{
      const sel = qs('#selectBeneficiary'); if(!sel.value) return alert('Choose beneficiary');
      const s = window.API.sanction(sel.value, 5000);
      alert('Sanctioned: '+s.id);
      renderStats();
    });
    disburseBtn && disburseBtn.addEventListener('click', ()=>{
      const sel = qs('#selectBeneficiary'); if(!sel.value) return alert('Choose beneficiary');
      const data = window.API.getAll();
      const s = data.sanctions.find(x=>x.beneficiaryId===sel.value && x.status!=='disbursed');
      if(!s) return alert('No pending sanction for this beneficiary');
      const d = window.API.disburse(s.id);
      alert('Disbursed: '+d.id);
      renderStats();
    });
  }

  // Admin page
  const exportBtn = qs('#exportCSV');
  if(exportBtn){
    exportBtn.addEventListener('click', ()=>{
      const data = window.API.exportCSV();
      const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = 'dbt-data.json'; document.body.appendChild(a); a.click(); a.remove();
    });
  }
  const clearBtn = qs('#clearData');
  if(clearBtn) clearBtn.addEventListener('click', ()=>{ if(confirm('Clear mock data?')){ window.API.reset(); location.reload(); }});

  const roleSel = qs('#roleSelect');
  const applyRole = qs('#applyRole');
  if(applyRole) applyRole.addEventListener('click', ()=>{
    const r = roleSel.value; localStorage.setItem('dbt_role', r); alert('Role applied: '+r);
  });

  // Service worker registration for offline-first
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('/js/sw.js').catch(()=>{});
  }
})();
